package com.example.springsecurityauthentication.business.impl;

public interface DeleteUserUseCase {
    void deleteUser(Long id);
}
