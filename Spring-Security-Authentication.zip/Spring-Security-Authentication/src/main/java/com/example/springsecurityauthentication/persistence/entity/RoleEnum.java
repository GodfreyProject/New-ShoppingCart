package com.example.springsecurityauthentication.persistence.entity;

public enum RoleEnum {



    SALES_MANAGER,
    ADMIN,
    CUSTOMER

}
