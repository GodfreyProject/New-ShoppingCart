package com.example.springsecurityauthentication.business.impl;


import com.example.springsecurityauthentication.dto.GetProductsResponseDTO;

public interface GetAllProductsUseCase {
    GetProductsResponseDTO getProducts();
}
