package com.example.springsecurityauthentication.business.impl;

public interface DeleteProductUseCase {
    void deleteProduct(Long id);
}
