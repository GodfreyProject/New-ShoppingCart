package com.example.springsecurityauthentication.persistence.entity;

public enum Category {

//    Mens_Wears,
//    Women_Wears,
//    Perfumes,
//    Casual,
//    Coperate


    Business_Attire,
    Cooperate_Wears,
    Sport_Wear,
    Formal_Wear,
    Casual_Wear,
    Cologne,
    Summer,
    Winter,
    Casual,
    Office_Wear
}
