package com.example.springsecurityauthentication.persistence.entity;

public enum PaymentType {

    CASH,
    CARD
}
